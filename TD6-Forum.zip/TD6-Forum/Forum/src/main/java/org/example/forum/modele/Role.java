package org.example.forum.modele;

public enum Role {
    ETUDIANT,
    ENSEIGNANT
}
