package org.example.forum.controleur.dtos;

public record LoginDTO(String email, String password) {
}
