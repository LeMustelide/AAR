package org.example.forum.modele.exceptions;

public class
LoginDejaUtiliseException extends Exception {
}
