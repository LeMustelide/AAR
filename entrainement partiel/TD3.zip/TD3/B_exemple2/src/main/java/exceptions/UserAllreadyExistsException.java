package exceptions;

public class UserAllreadyExistsException extends Exception {
}
