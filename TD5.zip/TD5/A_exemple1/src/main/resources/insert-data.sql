insert into COMPOSITE(IDCOMPOSITE,NOMCOMPOSITE) values (1,'ordinateur'),(2,'moto'),(3,'savonnette');

insert into COMPOSANT(IDCOMPOSANT,NOMCOMPOSANT,COMPOSITE_IDCOMPOSITE) values(1,'carte mère',1),(2,'carte graphique',1);

insert into COMPOSANT(IDCOMPOSANT,NOMCOMPOSANT,COMPOSITE_IDCOMPOSITE) values(3,'selle',2),(4,'roue avant',2);
