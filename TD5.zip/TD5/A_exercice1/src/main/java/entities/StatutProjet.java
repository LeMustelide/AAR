package entities;

public enum StatutProjet {
    CREE,
    PLANIFIE,
    ENCOURS,
    SUSPENDU,
    TERMINE
}
