--insert into CLIENTAVECCLEIDCLASS values('Lupine','Wonse');

--insert into CLIENTAVECCLEEMBEDDED values('Igné','Coupefin');
