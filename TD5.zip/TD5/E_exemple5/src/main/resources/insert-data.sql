insert into GROUPE(IDGROUPE,TAILLEGROUPE,LIBELLEGROUPE) values (1,24,'groupe1');
insert into GROUPE(IDGROUPE,TAILLEGROUPE,LIBELLEGROUPE) values (2,35,'groupe2');

insert into SALLE(IDSALLE,NOMSALLE,CAPACITE) values('1','E25',12);
insert into SALLE(IDSALLE,NOMSALLE,CAPACITE) values('2','Amphi H',120);

insert into MATIERE(IDMATIERE,INTITULEMATIERE) values('AAR','Ancien Alphabet Retrograde');
insert into MATIERE(IDMATIERE,INTITULEMATIERE) values('REST','Have a REST');
