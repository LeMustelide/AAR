package repositories;

import entities.Groupe;
import org.springframework.data.repository.CrudRepository;

public interface GroupeRepo extends CrudRepository<Groupe,Integer> {
}
