package repositories;

import entities.Matiere;
import org.springframework.data.repository.CrudRepository;

public interface MatiereRepo extends CrudRepository<Matiere,String> {
}
