package repositories;

import entities.Prerequis;
import org.springframework.data.repository.CrudRepository;

public interface PrerequisRepo extends CrudRepository<Prerequis,Integer> {
}
